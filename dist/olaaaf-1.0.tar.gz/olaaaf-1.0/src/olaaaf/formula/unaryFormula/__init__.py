"""
Representation of unary formulas, meaning formulas with only one argument.
"""

from .unaryFormula import UnaryFormula
from .notOperator import Not