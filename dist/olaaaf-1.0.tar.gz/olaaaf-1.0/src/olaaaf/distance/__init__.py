"""
Representation of distance functions and the domains they are defined on.
"""

from .distance_function import *

from .domain import *