"""
Representation of the domains that the distance functions are defined on.
"""

from .domain import Domain
from .variableTupleDomaine import VariableTupleDomaine